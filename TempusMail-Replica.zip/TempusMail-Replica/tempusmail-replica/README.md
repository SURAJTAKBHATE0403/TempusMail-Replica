# TempusMail Replica (Developer Internship Assessment)

## 🌟 प्रोजेक्टचे उद्दिष्ट
हा प्रकल्प तात्पुरत्या (Disposable) ईमेल ॲड्रेस जनरेट करतो आणि इनबॉक्समध्ये प्राप्त झालेले ईमेल दाखवतो. तसेच, हे ॲप Notion API वापरून ब्लॉग पोस्ट कार्ड्स प्रदर्शित करते.

## 🛠️ टेक्नॉलॉजी स्टॅक
* **फ्रंटएंड (Frontend):** VanillaJS (HTML, CSS, JavaScript)
* **बॅकएंड (Backend):** Express JS (Node.js)
* **ईमेल API:** Mail.tm
* **डेटा/CMS API:** Notion API
* **डिप्लॉयमेंट (Deployment):** Firebase App Hosting

## 🚀 लोकल सेटअप (Local Setup)

### 1. फ्रंटएंड आणि बॅकएंड पॅकेजेस स्थापित करा
प्रोजेक्ट रूट मध्ये:
```bash
# ॲप-व्यापी नोड पॅकेजेस (या प्रकरणात, फक्त server/ मध्ये आहे)
cd server
npm install
# (येथे तुम्ही notionhq/client, express, axios, dotenv स्थापित केले आहेत.)