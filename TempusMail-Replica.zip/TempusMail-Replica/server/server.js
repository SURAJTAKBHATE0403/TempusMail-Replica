// १. आवश्यक पॅकेजेस आणि कॉन्फिगरेशन लोड करा
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');
const { Client } = require('@notionhq/client'); // Notion Client import केले

const MAIL_TM_API_URL = 'https://api.mail.tm';

// २. Express ॲप तयार करा
const app = express();
const PORT = process.env.PORT || 3000;

// ३. Notion Configuration
// NOTION_TOKEN आणि NOTION_DATABASE_ID हे process.env मधून घेतले जातील.
const NOTION_TOKEN = process.env.NOTION_TOKEN;
const NOTION_DATABASE_ID = process.env.NOTION_DATABASE_ID;

const notion = NOTION_TOKEN ? new Client({ auth: NOTION_TOKEN }) : null;

// ४. Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'src')));

// ५. रूट एन्ड्पॉइंट (Frontend सर्व्ह करण्यासाठी)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'src', 'index.html'));
});

// ---------------------------
// Generate Email Endpoint
// ---------------------------
app.post('/api/generate-email', async (req, res) => {
    console.log('--- Attempting to generate new Mail.tm account ---');
    let newAccountData = {};

    try {
        const domainResponse = await axios.get(`${MAIL_TM_API_URL}/domains`);
        const domainList = domainResponse.data['hydra:member'] || [];
        if (domainList.length === 0) {
            console.error('ERROR: No domains available from Mail.tm');
            return res.status(503).json({
                status: 'api_unavailable',
                message: 'No Mail.tm domains available. Please try later.'
            });
        }

        const domainId = domainList[0]['@id'];
        const domainName = domainList[0].domain;
        console.log(`Step 1/3: Fetched Domain: ${domainName}`);

        const username = Math.random().toString(36).substring(2, 10);
        const password = 'TempusMailPassword123';

        newAccountData = {
            address: `${username}@${domainName}`,
            password: password,
            domain: domainId
        };

        const accountResponse = await axios.post(`${MAIL_TM_API_URL}/accounts`, newAccountData);
        const account = accountResponse.data;
        console.log(`Step 2/3: SUCCESS: Account created: ${account.address}`);

        const loginResponse = await axios.post(`${MAIL_TM_API_URL}/token`, {
            address: newAccountData.address,
            password: newAccountData.password,
        });

        const token = loginResponse.data.token;
        console.log(`Step 3/3: SUCCESS: Logged in and received Token.`);

        const expirySeconds = 900;

        res.json({
            status: 'success',
            email: account.address,
            accountId: account['@id'],
            token: token,
            expiresIn: expirySeconds
        });

    } catch (error) {
        if (error.response) {
            console.error('API Response Error (Status %s): %s', error.response.status, JSON.stringify(error.response.data, null, 2));
            const userMessage = error.response.data.detail || 'The Mail.tm API returned an unknown error.';
            return res.status(error.response.status).json({
                status: 'api_error',
                message: 'Failed to generate email address due to external API issue.',
                detail: userMessage
            });
        } else {
            console.error('Network or Unknown Error:', error.message);
            return res.status(500).json({
                status: 'server_error',
                message: 'Server failed to connect to the external API or network error.',
                detail: error.message
            });
        }
    }
});

// ---------------------------
// Fetch Inbox Endpoint
// ---------------------------
app.post('/api/fetch-inbox', async (req, res) => {
    const { token } = req.body;
    if (!token) return res.status(400).json({ status: 'error', message: 'Authorization token is missing.' });

    try {
        console.log('--- Attempting to fetch inbox messages ---');
        const messageResponse = await axios.get(`${MAIL_TM_API_URL}/messages`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        res.json({ status: 'success', emails: messageResponse.data['hydra:member'] || [] });
        console.log(`SUCCESS: Fetched ${messageResponse.data['hydra:member']?.length || 0} messages.`);
    } catch (error) {
        if (error.response) {
            console.error('API Response Error (Status %s) during inbox fetch: %s', error.response.status, error.response.data.detail || error.response.data.message);
            return res.status(error.response.status).json({ status: 'auth_error', message: 'Failed to fetch inbox. Invalid session token.', detail: error.response.data.detail || 'API request failed.' });
        } else {
            console.error('Network or Unknown Error during inbox fetch:', error.message);
            return res.status(500).json({ status: 'server_error', message: 'Server failed to connect to external API during inbox fetch.', detail: error.message });
        }
    }
});

// ---------------------------
// Fetch Single Email Details Endpoint
// ---------------------------
app.post('/api/get-email-details', async (req, res) => {
    const { token, messageId } = req.body;
    if (!token || !messageId) return res.status(400).json({ status: 'error', message: 'Token or messageId missing in request.' });
    
    try {
        console.log(`--- Attempting to fetch details for email ${messageId} ---`);
        const emailResponse = await axios.get(`${MAIL_TM_API_URL}/messages/${messageId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        res.json({ status: 'success', email: emailResponse.data });
        console.log(`SUCCESS: Fetched email details for ${messageId}`);
    } catch (error) {
        if (error.response) {
            console.error('API Response Error (Status %s) during email fetch: %s', error.response.status, error.response.data.detail || error.response.data.message);
            return res.status(error.response.status).json({ status: 'auth_error', message: 'Failed to fetch email details. Invalid session token or messageId.', detail: error.response.data.detail || 'API request failed.' });
        } else {
            console.error('Network or Unknown Error during email fetch:', error.message);
            return res.status(500).json({ status: 'server_error', message: 'Server failed to connect to external API during email fetch.', detail: error.message });
        }
    }
});

// ---------------------------
// Notion Blog Articles Logic
// ---------------------------
app.get('/api/notion-cards', async (req, res) => {
    console.log('--- Attempting to fetch Notion Cards ---');
    // Notion client आणि Database ID अस्तित्वात असल्याची खात्री करा
    if (!notion || !NOTION_DATABASE_ID) {
        console.warn('Notion client or database ID is missing. Using mock data.');
        // जर Notion API उपलब्ध नसेल, तर Mock data परत पाठवा.
        const mockCards = [
            { id: '1', title: 'Why Use TempusMail?', description: 'Protect your privacy and avoid spam with our disposable addresses.', icon: '✉️' },
            { id: '2', title: 'Email Security Tips', description: 'Learn how to keep your real inbox clean and secure from phishing.', icon: '🔒' },
            { id: '3', title: 'Notion Integration Guide', description: 'How we use Notion to manage our blog content efficiently.', icon: '📄' },
        ];
        // 200 OK (पण Mock data सोबत)
        return res.status(200).json({ cards: mockCards, message: 'Notion API not configured. Showing mock data.' });
    }

    try {
        // Notion डेटाबेसमधून Query करा (Blog Post data)
        const response = await notion.databases.query({
            database_id: NOTION_DATABASE_ID,
            // 'Status' property 'Published' असलेल्या पोस्ट्ससाठी फिल्टर करा
            filter: {
                property: 'Status',
                select: {
                    equals: 'Published',
                },
            },
            // 'Date' property नुसार उतरत्या क्रमाने (Descending) सॉर्ट करा
            sorts: [
                {
                    property: 'Date',
                    direction: 'descending',
                },
            ],
            page_size: 3, // फक्त 3 कार्ड्स आणा
        });

        // Notion properties मधून आवश्यक डेटा Extractor करा
        const cards = response.results.map((page) => {
            const properties = page.properties;
            return {
                id: page.id,
                title: properties.Name?.title?.[0]?.plain_text || 'Untitled',
                description: properties.Description?.rich_text?.[0]?.plain_text || 'No description available.',
                icon: page.icon?.emoji || '📄',
            };
        });

        res.json({ status: 'success', cards });

    } catch (error) {
        console.error('Error fetching Notion cards:', error.message);
        // Error आल्यास Mock data परत पाठवा (Fail-safe mechanism)
        const mockCards = [
            { id: '1', title: 'Why Use TempusMail?', description: 'Protect your privacy and avoid spam with our disposable addresses.', icon: '✉️' },
            { id: '2', title: 'Email Security Tips', description: 'Learn how to keep your real inbox clean and secure from phishing.', icon: '🔒' },
            { id: '3', title: 'Notion Integration Guide', description: 'How we use Notion to manage our blog content efficiently.', icon: '📄' },
        ];
        res.status(500).json({ status: 'server_error', error: 'Failed to fetch articles from Notion. Showing mock data.', cards: mockCards });
    }
});

// ८. सर्वर सुरू करा
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Frontend is served from: ${path.join(__dirname, '..', 'src')}`);
});
