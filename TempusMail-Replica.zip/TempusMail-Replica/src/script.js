const API_URL = '/api/generate-email';
const FETCH_INBOX_URL = '/api/fetch-inbox';

const generateButton = document.getElementById('generate-button');
const generatedEmailElement = document.getElementById('generated-email');
const emailInfoSection = document.getElementById('email-info');
const inboxSection = document.getElementById('inbox-section');
const emailBoxCard = document.querySelector('.email-box-card');
const emailHeading = document.getElementById('email-heading');
const emailSubheading = document.getElementById('email-subheading');

let timerInterval;
let currentToken = null;

// ----------------------
// Utility Functions
// ----------------------
function showModal(message, type = 'success', duration = 5000) {
    const modalContainer = document.createElement('div');
    modalContainer.className = `app-modal ${type}`;
    modalContainer.innerHTML = `<div class="modal-content"><p>${message}</p></div>`;
    document.body.appendChild(modalContainer);

    // Animate in
    setTimeout(() => {
        const content = modalContainer.querySelector('.modal-content');
        content.style.opacity = '1';
        content.style.transform = 'translateX(0)';
    }, 50);

    // Auto remove after duration
    setTimeout(() => {
        const content = modalContainer.querySelector('.modal-content');
        content.style.opacity = '0';
        content.style.transform = 'translateX(100%)';
        setTimeout(() => modalContainer.remove(), 300);
    }, duration);
}

function setButtonLoading(isLoading) {
    if (isLoading) {
        generateButton.disabled = true;
        generateButton.innerHTML = `<svg class="loading-spinner" width="20" height="20"><path d="M12 4V2C12 1.44772 11.5523 1 11 1C10.4477 1 10 1.44772 10 2V4C10 4.55228 10.4477 5 11 5C11.5523 5 12 4.55228 12 4Z" fill="white"/></svg> Generating...`;
    } else {
        generateButton.disabled = false;
        generateButton.innerHTML = 'Generate';
    }
}

function copyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    try { 
        document.execCommand('copy'); 
        showModal('Email copied!', 'success'); 
    } catch { 
        showModal('Copy failed!', 'error'); 
    }
    document.body.removeChild(textArea);
}

// ----------------------
// Timer
// ----------------------
function startTimer(duration) {
    let timeLeft = duration;
    const timerElement = document.getElementById('email-timer-value');
    if (timerInterval) clearInterval(timerInterval);

    timerInterval = setInterval(() => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerElement.textContent = `${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            emailHeading.textContent = 'Session Expired';
            emailHeading.style.color = 'red';
            emailSubheading.textContent = 'Please generate a new temporary email.';
            generatedEmailElement.textContent = 'Session Expired';
            generatedEmailElement.style.color = 'red';
            emailInfoSection.classList.add('hidden');
            inboxSection.classList.add('hidden');
            generateButton.classList.remove('hidden');
            showModal('Email session expired.', 'error', 5000);
        }
        timeLeft--;
    }, 1000);
}

// ----------------------
// Fetch Inbox
// ----------------------
async function fetchInbox(token) {
    try {
        const res = await fetch(FETCH_INBOX_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token })
        });
        if (!res.ok) throw new Error('Failed to fetch inbox');
        const data = await res.json();
        renderInbox(data.emails || []);
    } catch (err) {
        console.error('Inbox fetch error:', err);
        inboxSection.innerHTML = '<p style="color:red; text-align:center;">Failed to fetch inbox.</p>';
        showModal('Failed to fetch inbox. Please try again.', 'error', 5000);
    }
}


function renderInbox(emails) {
    inboxSection.innerHTML = '';
    if (!emails || emails.length === 0) {
        inboxSection.innerHTML = '<p>No messages yet.</p>';
        return;
    }
    emails.forEach(email => {
        const div = document.createElement('div');
        div.className = 'inbox-email-card';
        div.innerHTML = `
            <p><strong>From:</strong> ${email.from?.address || 'Unknown'}</p>
            <p><strong>Subject:</strong> ${email.subject || '(No Subject)'}</p>
            <p>${email.intro || ''}</p>
        `;
        // -----------------------------
        // Click handler for Modal
        // -----------------------------
        div.addEventListener('click', async () => {
            if (!currentToken) return showModal('No active session.', 'error');
            try {
                const res = await fetch('/api/get-email-details', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ token: currentToken, messageId: email.id })
                });
                if (!res.ok) throw new Error('Failed to fetch email details');
                const data = await res.json();
                showEmailModal(data.email);
            } catch (err) {
                console.error('Email fetch error:', err);
                showModal('Failed to fetch email details.', 'error');
            }
        });

        inboxSection.appendChild(div);
    });
}

// -----------------------------
// Modal to show full email
// -----------------------------
function showEmailModal(email) {
    // Remove existing modal if any
    const existing = document.querySelector('.email-detail-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'email-detail-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h3>From: ${email.from?.address || 'Unknown'}</h3>
            <h4>Subject: ${email.subject || '(No Subject)'}</h4>
            <div class="email-body">
                ${email.html 
                    ? email.html 
                    : `<pre>${email.text || '(No Content)'}</pre>`}
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    // Close button
    modal.querySelector('.close-btn').addEventListener('click', () => modal.remove());

    // Click outside modal to close
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.remove();
    });
}


// ----------------------
// Generate Email
// ----------------------
async function generateNewEmail() {
    setButtonLoading(true);
    try {
        const response = await fetch(API_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' } });
        if (!response.ok) throw new Error('Server error: unable to generate email');
        const data = await response.json();
        const { email, token, expiresIn } = data;
        currentToken = token;

        generatedEmailElement.textContent = email;
        generatedEmailElement.style.color = '#1F2937';
        emailHeading.textContent = 'Your Temporary Email Address';
        emailHeading.style.color = '#1F2937';
        emailSubheading.textContent = 'Active for time remaining below';
        generateButton.classList.add('hidden');

        renderEmailControls(email, expiresIn);
        emailInfoSection.classList.remove('hidden');
        inboxSection.classList.remove('hidden');

        startTimer(expiresIn);
        showModal(`Email generated: ${email}`, 'success');

        fetchInbox(token);
        setInterval(() => fetchInbox(token), 10000);

    } catch (err) {
        console.error(err);
        generatedEmailElement.textContent = 'Failed to generate email!';
        generatedEmailElement.style.color = 'red';
        emailInfoSection.classList.add('hidden');
        inboxSection.classList.add('hidden');
        showModal(err.message || 'Failed to generate email.', 'error', 5000);
    } finally {
        setButtonLoading(false);
    }
}

// ----------------------
// Email Controls
// ----------------------
function renderEmailControls(email, duration) {
    emailInfoSection.innerHTML = `
        <div class="email-controls">
            <button id="copy-button" class="action-button small">Copy</button>
            <button id="new-email-button" class="action-button small">New Email</button>
        </div>
        <span id="email-timer">Expires in: <span id="email-timer-value">--:--</span></span>
    `;
    document.getElementById('copy-button').addEventListener('click', () => copyToClipboard(email));
    document.getElementById('new-email-button').addEventListener('click', () => {
        if (timerInterval) clearInterval(timerInterval);
        generateButton.classList.remove('hidden');
        generatedEmailElement.textContent = "Click 'Generate' to get an email";
        generatedEmailElement.style.color = '#1F2937';
        emailHeading.textContent = 'Instant, Temporary Email Address';
        emailHeading.style.color = '#1F2937';
        emailSubheading.textContent = "Click 'Generate' to get your disposable email address.";
        emailInfoSection.classList.add('hidden');
        inboxSection.classList.add('hidden');
        showModal('Email session cancelled. ', 'error', 5000);
    });
}

// ----------------------
// Initialize
// ----------------------
generateButton.addEventListener('click', generateNewEmail);

window.onload = () => {
    console.log('Script initialized.');
};
