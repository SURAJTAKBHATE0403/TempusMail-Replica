// src/components/BlogCard/BlogCard.js

const notionCardsElement = document.getElementById('notion-cards');

/**
 * ब्लॉग कार्ड्स बॅकएंड API कडून फेच करते आणि रेंडर करते.
 */
export async function fetchAndRenderBlogCards() {
    if (!notionCardsElement) return;

    notionCardsElement.innerHTML = '<p class="inbox-status">Loading latest articles...</p>';
    
    try {
        const response = await fetch('/api/notion-cards');
        if (!response.ok) {
            throw new Error(`Failed to fetch notion cards: ${response.status}`);
        }
        
        const data = await response.json();
        const articles = data.articles || [];
        
        renderBlogCards(articles);
        
    } catch (error) {
        console.error('Notion fetch error:', error);
        notionCardsElement.innerHTML = '<p class="inbox-status error">Failed to load articles.</p>';
    }
}

/**
 * मिळालेले लेख DOM मध्ये रेंडर करते.
 */
function renderBlogCards(articles) {
    if (!notionCardsElement) return;

    if (articles.length === 0) {
        notionCardsElement.innerHTML = '<p class="inbox-status">No published articles found.</p>';
        return;
    }

    notionCardsElement.innerHTML = ''; // Clean up

    articles.forEach(article => {
        const card = document.createElement('div');
        card.classList.add('blog-card');
        // A click will lead to a page that says "Page Under Construction"
        card.onclick = () => window.location.href = '/page-under-construction.html'; 

        const tagsHtml = article.tags.map(tag => `<span class="tag">${tag}</span>`).join('');

        card.innerHTML = `
            <img src="${article.coverUrl}" alt="${article.title} cover" class="card-image">
            <div class="card-content">
                <div class="card-tags">${tagsHtml}</div>
                <h3 class="card-title">${article.title}</h3>
                <p class="card-intro">${article.intro}</p>
            </div>
        `;
        notionCardsElement.appendChild(card);
    });
}

/**
 * BlogCard Component Logic चा सेटअप.
 */
export function setupBlogCardsLogic() {
    fetchAndRenderBlogCards();
}