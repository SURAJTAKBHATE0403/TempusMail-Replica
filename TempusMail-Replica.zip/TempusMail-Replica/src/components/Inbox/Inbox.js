// src/components/Inbox/Inbox.js

const POLLING_INTERVAL = 5000; // 5 सेकंदात एकदा तपासा (Adjust as needed)
let pollingTimer = null;

// EmailBox मधून वापरलेले Keys
const CURRENT_EMAIL_KEY = 'tempMailAddress';
const CURRENT_TOKEN_KEY = 'tempMailToken';

const emailListElement = document.getElementById('email-list');
const inboxSection = document.getElementById('inbox-section');

/**
 * Mail.tm API कडून ईमेल फेच करते.
 * @param {string} token - Mail.tm JWT Token
 */
async function fetchEmails(token) {
    if (!emailListElement) return [];
    
    // Status update
    if (emailListElement.innerHTML === '') {
         emailListElement.innerHTML = '<p class="inbox-status">Checking for new emails...</p>';
    }

    try {
        // बॅकएंड API ला कॉल करा (टोकन Query Parameter म्हणून पाठवा)
        const response = await fetch(`/api/inbox?token=${token}`);
        
        if (!response.ok) {
            throw new Error(`Failed to fetch inbox: ${response.status}`);
        }

        const data = await response.json();
        return data.emails || [];

    } catch (error) {
        console.error('Email fetching error:', error);
        emailListElement.innerHTML = '<p class="inbox-status error">Error loading inbox. Check server.</p>';
        return [];
    }
}

/**
 * मिळालेले ईमेल DOM मध्ये रेंडर करते.
 * @param {Array} emails - प्राप्त झालेल्या ईमेलची यादी.
 */
function renderEmails(emails) {
    if (!emailListElement) return;

    if (emails.length === 0) {
        emailListElement.innerHTML = '<p class="inbox-status">Waiting for your first email...</p>';
        return;
    }

    emailListElement.innerHTML = ''; // Clean up before rendering

    emails.forEach(email => {
        const item = document.createElement('div');
        item.classList.add('email-item');
        
        // Date formatting for better readability
        const date = new Date(email.createdAt).toLocaleTimeString('en-IN', {
            hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short'
        });

        item.innerHTML = `
            <div class="email-header">
                <span class="email-sender">From: ${email.from.address}</span>
                <span class="email-date">${date}</span>
            </div>
            <div class="email-subject">${email.subject || '(No Subject)'}</div>
            <p style="font-size:0.9em; opacity:0.8;">${email.intro}</p>
        `;
        // TODO: Add logic here to display full email content on click (Optional but nice to have)
        
        emailListElement.appendChild(item);
    });
}

/**
 * इनबॉक्स तपासण्याची प्रक्रिया सुरू करते.
 */
export async function startInboxPolling() {
    // Stop any existing timer
    if (pollingTimer) {
        clearInterval(pollingTimer);
    }
    
    const token = localStorage.getItem(CURRENT_TOKEN_KEY);
    const emailAddress = localStorage.getItem(CURRENT_EMAIL_KEY);

    if (!token || !emailAddress) {
        if(emailListElement) {
             emailListElement.innerHTML = '<p class="inbox-status">Generate an email address to activate inbox.</p>';
        }
        return;
    }

    // Polling function
    const poll = async () => {
        const emails = await fetchEmails(token);
        renderEmails(emails);
    };

    // Start immediately and then repeat every POLLING_INTERVAL
    await poll(); 
    pollingTimer = setInterval(poll, POLLING_INTERVAL);

    console.log(`Polling started for: ${emailAddress} every ${POLLING_INTERVAL / 1000}s`);
}

/**
 * Inbox Component Logic चा सेटअप.
 */
export function setupInboxLogic() {
    // Attach the polling function globally so EmailBox can call it after generation.
    // NOTE: This uses the global window object for component communication, typical in VanillaJS.
    window.startInboxPolling = startInboxPolling;
    
    // Check and start polling on page load if an email is already stored
    startInboxPolling();
}