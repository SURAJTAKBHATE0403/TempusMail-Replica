// src/components/EmailBox/EmailBox.js

// लोकल स्टोरेजसाठी Key: 
const CURRENT_EMAIL_KEY = 'tempMailAddress';
const CURRENT_TOKEN_KEY = 'tempMailToken';

export function setupEmailBoxLogic() {
    const tempEmailInput = document.getElementById('temp-email');
    const generateBtn = document.getElementById('generate-btn');
    const copyBtn = document.getElementById('copy-btn');

    // आवश्यक DOM घटक तपासणे
    if (!tempEmailInput || !generateBtn || !copyBtn) return;

    // 1. पेज लोड झाल्यावर साठवलेला डेटा तपासा
    const storedEmail = localStorage.getItem(CURRENT_EMAIL_KEY);
    if (storedEmail) {
        tempEmailInput.value = storedEmail;
        generateBtn.textContent = 'Inbox Ready';
        generateBtn.disabled = false; // बटण सक्रिय ठेवा
        copyBtn.style.display = 'block';

        // ⭐️ सुधारणा १: पेज लोड झाल्यावर Polling सुरू करा
        if (window.startInboxPolling) { 
            window.startInboxPolling(); 
        }
    } else {
        copyBtn.style.display = 'none';
        generateBtn.textContent = 'Generate';
        generateBtn.disabled = false;
    }


    // 2. ईमेल जनरेशन लॉजिक
    generateBtn.addEventListener('click', async () => {
        if (generateBtn.textContent === 'Inbox Ready') return; 

        generateBtn.textContent = 'Generating...';
        generateBtn.disabled = true;
        tempEmailInput.value = ''; // UI लगेच साफ करा
        
        try {
            // बॅकएंड API ला कॉल करा
            const response = await fetch('/api/generate-email'); 
            
            if (!response.ok) {
                 throw new Error(`Server returned status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.email && data.token) {
                // मिळालेला डेटा लोकल स्टोरेजमध्ये सुरक्षितपणे साठवा
                localStorage.setItem(CURRENT_EMAIL_KEY, data.email);
                localStorage.setItem(CURRENT_TOKEN_KEY, data.token);

                tempEmailInput.value = data.email;
                generateBtn.textContent = 'Inbox Ready';
                copyBtn.style.display = 'block';
                
                // ⭐️ सुधारणा २: ईमेल जनरेट झाल्यावर Polling सुरू करा
                if (window.startInboxPolling) { 
                    window.startInboxPolling(); 
                }

            } else {
                tempEmailInput.value = data.message || 'Generation failed.';
            }
        } catch (error) {
            console.error('Email generation failed:', error);
            tempEmailInput.value = 'Error! Try again.';
        } finally {
            generateBtn.disabled = false;
        }
    });

    // 3. कॉपी करण्याची लॉजिक (Modern API वापरणे)
    copyBtn.addEventListener('click', () => {
        // navigator.clipboard.writeText वापरणे
        navigator.clipboard.writeText(tempEmailInput.value).then(() => {
            copyBtn.textContent = 'Copied!';
            setTimeout(() => {
                copyBtn.textContent = 'Copy';
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            copyBtn.textContent = 'Error Copying';
        });
    });
}