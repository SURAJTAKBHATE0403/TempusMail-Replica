// main.js (Frontend entry point)
const CURRENT_EMAIL_KEY = 'tempMailAddress';
const CURRENT_TOKEN_KEY = 'tempMailToken';
const POLLING_INTERVAL = 5000;

let pollingTimer = null;

// ---------- EmailBox Logic ----------
function setupEmailBox() {
    const tempEmailInput = document.getElementById('temp-email');
    const generateBtn = document.getElementById('generate-btn');
    const copyBtn = document.getElementById('copy-btn');
    if (!tempEmailInput || !generateBtn || !copyBtn) return;

    const storedEmail = localStorage.getItem(CURRENT_EMAIL_KEY);
    if (storedEmail) {
        tempEmailInput.value = storedEmail;
        generateBtn.textContent = 'Inbox Ready';
        generateBtn.disabled = false;
        copyBtn.style.display = 'block';
        startInboxPolling();
    } else {
        copyBtn.style.display = 'none';
        generateBtn.textContent = 'Generate';
        generateBtn.disabled = false;
    }

    generateBtn.addEventListener('click', async () => {
        if (generateBtn.textContent === 'Inbox Ready') return;
        generateBtn.textContent = 'Generating...';
        generateBtn.disabled = true;
        tempEmailInput.value = '';

        try {
            const res = await fetch('/api/generate-email', { method: 'POST' });
            if (!res.ok) throw new Error(`Server error ${res.status}`);
            const data = await res.json();

            if (data.email && data.token) {
                localStorage.setItem(CURRENT_EMAIL_KEY, data.email);
                localStorage.setItem(CURRENT_TOKEN_KEY, data.token);
                tempEmailInput.value = data.email;
                generateBtn.textContent = 'Inbox Ready';
                copyBtn.style.display = 'block';
                startInboxPolling();
            } else {
                tempEmailInput.value = data.message || 'Failed to generate';
            }
        } catch (e) {
            console.error(e);
            tempEmailInput.value = 'Error!';
        } finally {
            generateBtn.disabled = false;
        }
    });

    copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(tempEmailInput.value)
            .then(() => {
                copyBtn.textContent = 'Copied!';
                setTimeout(() => copyBtn.textContent = 'Copy', 2000);
            })
            .catch(err => {
                console.error(err);
                copyBtn.textContent = 'Error';
            });
    });
}

// ---------- Inbox Logic ----------
function setupInbox() {
    window.startInboxPolling = startInboxPolling;
    startInboxPolling();
}

async function fetchEmails(token) {
    const emailList = document.getElementById('email-list');
    if (!emailList) return [];
    emailList.innerHTML = '<p class="inbox-status">Checking for emails...</p>';

    try {
        const res = await fetch('/api/fetch-inbox', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token })
        });
        if (!res.ok) throw new Error(`Inbox fetch failed: ${res.status}`);
        const data = await res.json();
        return Array.isArray(data.emails) ? data.emails : [];
    } catch (e) {
        console.error('Inbox fetch error:', e);
        emailList.innerHTML = '<p class="inbox-status error">Failed to load inbox</p>';
        return [];
    }
}

function renderEmails(emails) {
    const emailList = document.getElementById('email-list');
    if (!emailList) return;

    if (!emails || emails.length === 0) {
        emailList.innerHTML = '<p class="inbox-status">Waiting for your first email...</p>';
        return;
    }

    emailList.innerHTML = '';
    emails.forEach(email => {
        const item = document.createElement('div');
        item.className = 'email-item';

        const sender = email.from?.address || 'Unknown';
        const subject = email.subject || '(No Subject)';
        const intro = email.intro || '';
        const dateStr = email.createdAt ? new Date(email.createdAt).toLocaleString('en-IN', {
            hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short'
        }) : '';

        item.innerHTML = `
            <div class="email-header">
                <span class="email-sender">From: ${sender}</span>
                <span class="email-date">${dateStr}</span>
            </div>
            <div class="email-subject">${subject}</div>
            <p style="font-size:0.9em; opacity:0.8;">${intro}</p>
        `;
        emailList.appendChild(item);
    });
}

async function startInboxPolling() {
    if (pollingTimer) clearInterval(pollingTimer);

    const token = localStorage.getItem(CURRENT_TOKEN_KEY);
    const emailAddress = localStorage.getItem(CURRENT_EMAIL_KEY);
    const emailList = document.getElementById('email-list');

    if (!token || !emailAddress) {
        if (emailList) emailList.innerHTML = '<p class="inbox-status">Generate an email to activate inbox.</p>';
        return;
    }

    const poll = async () => {
        const emails = await fetchEmails(token);
        renderEmails(emails);
    };

    await poll();
    pollingTimer = setInterval(poll, POLLING_INTERVAL);
}

// ---------- Initialize ----------
document.addEventListener('DOMContentLoaded', () => {
    setupEmailBox();
    setupInbox();
});
